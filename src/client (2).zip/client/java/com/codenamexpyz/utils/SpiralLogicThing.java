package com.codenamexpyz.utils;

import com.codenamexpyz.utils.Rotator;

import net.minecraft.client.particle.Particle;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.util.math.Vec3d;

import static com.codenamexpyz.ArcadiaParticlesClient.mc;

import org.joml.Vector3d;

public class SpiralLogicThing {
    private static void circle(Vec3d pos, double radius, double yRot) {
        double circleStep = 180;
        double xRot = 0;
        double zRot = 0;
        float scale = 0.2f;

        for (int i = 0; i < 360; i += circleStep) {
            double angle = Math.toRadians(i);
            double xOffset = Math.cos(angle) * radius;
            double zOffset = Math.sin(angle) * radius;

            Rotator rotator = new Rotator();
            
            rotator.rotateYQuaternion((float)(Math.toRadians(yRot)));
            rotator.rotateXQuaternion((float)(Math.toRadians(xRot)));
            rotator.rotateZQuaternion((float)(Math.toRadians(zRot)));
            
            Vector3d rot = rotator.rotateVectorQuaternion(new Vector3d(xOffset, 0, zOffset));
            
            double particleX = pos.getX() + rot.x;
            double particleY = pos.getY() + rot.y;
            double particleZ = pos.getZ() + rot.z;

            Particle particle = mc.particleManager.addParticle(new DustParticleEffect(1, 1), particleX, particleY, particleZ, 0, 0, 0);
            particle.setMaxAge(10);
            particle.scale(scale);
        }
    }
}

/*
 * Radius increases along side yRot degrees, makes it spin!
 */