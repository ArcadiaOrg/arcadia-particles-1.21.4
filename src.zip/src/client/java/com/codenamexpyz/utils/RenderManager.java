package com.codenamexpyz.utils;

import net.minecraft.client.gl.CompiledShader;
import net.minecraft.client.gl.Defines;
import net.minecraft.client.gl.PostEffectPipeline;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.gl.ShaderLoader;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.PostEffectProcessor.FramebufferSet;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import com.mojang.blaze3d.systems.RenderSystem;

import static com.codenamexpyz.ArcadiaParticlesClient.MOD_ID;
import static com.codenamexpyz.ArcadiaParticlesClient.mc;

import java.io.InputStreamReader;
import java.util.Set;

import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;

public class RenderManager {
    private static ShaderProgramKey key;
    private static PostEffectProcessor postKey;
    
    public static void test() {
        key = new ShaderProgramKey(Identifier.of(MOD_ID, "program/monochrome"), VertexFormats.POSITION_TEXTURE, Defines.EMPTY);
        mc.getShaderLoader().getOrCreateProgram(key);

        //mc.getShaderLoader().loadPostEffect(null, null);
    }

    public static void test2() {
        Set<Identifier> targets = Set.of(
            Identifier.ofVanilla("main"),
            Identifier.ofVanilla("out"),
            Identifier.ofVanilla("effect"),
            Identifier.ofVanilla("swap")
        );
        try {
            mc.getShaderLoader().loadPostEffect(Identifier.of(MOD_ID, "post/test"), targets);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static PostEffectProcessor loadShader() {
        Identifier pipelineId = Identifier.of("arcadia-particles", "post/monochrome");
        Set<Identifier> sets = Set.of(Identifier.of("minecraft", "main"));

        try {
            return PostEffectProcessor.parseEffect(getPipeline(pipelineId), mc.getTextureManager(), mc.getShaderLoader(), sets);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static PostEffectPipeline getPipeline(Identifier pipelineId) {
        try {
            var reader = new InputStreamReader(mc.getResourceManager().getResourceOrThrow(pipelineId).getInputStream());
            var jsonElement = JsonParser.parseReader(reader);
            var result = PostEffectPipeline.CODEC.parse(JsonOps.INSTANCE, jsonElement);
            return result.result().orElseThrow(() ->
                new IllegalStateException("Failed to decode PostEffectPipeline: " + pipelineId)
            );
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}