package com.codenamexpyz;

import java.util.Set;

import org.lwjgl.opengl.GL11;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.codenamexpyz.utils.ParticleManager;
import com.codenamexpyz.utils.RenderManager;
import com.mojang.blaze3d.systems.RenderSystem;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Defines;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

public class ArcadiaParticlesClient implements ClientModInitializer {
	public static final String MOD_ID = "arcadia-particles";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static MinecraftClient mc;

	@Override
	public void onInitializeClient() {
		mc = MinecraftClient.getInstance();
		

		ClientTickEvents.END_CLIENT_TICK.register(clientTick -> {	
			if (mc.world != null && !mc.isPaused()) { 
				ParticleManager.handleParticles();
			}
		});

		WorldRenderEvents.END.register(context -> { 
			if (mc.player != null) {
				if (mc.player.isSneaking()) {
					applyFullscreenShader(mc.getFramebuffer());
				}
			}
		});
	}

	public static void applyFullscreenShader(Framebuffer inputFramebuffer) {
		RenderSystem.disableDepthTest(); 
		RenderSystem.depthMask(false);
		RenderSystem.colorMask(true, true, true, true);
		RenderSystem.disableCull();
		RenderSystem.disableBlend();
		RenderSystem.defaultBlendFunc();

		RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL11.GL_CLAMP);
		RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL11.GL_CLAMP);

		Tessellator tessellator = Tessellator.getInstance();
		BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

		int width = inputFramebuffer.textureWidth;
		int height = inputFramebuffer.textureHeight;

		buffer.vertex( 1,  1, 0).texture(1, 1).color(0.0f, 0.0f, 0.0f, 1.0f)
			.vertex( 1, -1, 0).texture(1, 0).color(0.0f, 0.0f, 0.0f, 1.0f)
			.vertex(-1, -1, 0).texture(0, 0).color(0.0f, 0.0f, 0.0f, 1.0f)
			.vertex(-1,  1, 0).texture(0, 1).color(0.0f, 0.0f, 0.0f, 1.0f);

		RenderSystem.setShader(new ShaderProgramKey(Identifier.of(MOD_ID, "post/monochrome"), VertexFormats.POSITION_TEXTURE_COLOR, Defines.EMPTY));
		RenderSystem.setShaderTexture(0, inputFramebuffer.getColorAttachment());
		RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
		
		BufferRenderer.drawWithGlobalProgram(buffer.end());

		
		RenderSystem.enableDepthTest();
		RenderSystem.depthMask(true);
	}
}

/*
 * 
 */